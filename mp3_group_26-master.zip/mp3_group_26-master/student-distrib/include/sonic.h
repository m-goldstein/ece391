#ifndef SONIC_C
#define SONIC_C
void splash_sonic(); /* show the Sonic ASCII art  */
#endif
