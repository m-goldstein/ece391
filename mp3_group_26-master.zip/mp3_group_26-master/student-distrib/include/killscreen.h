#ifndef KILLSCREEN_H
#define KILLSCREEN_H
#include "lib.h"
extern void show_kill_screen(); /* dump the register values when the exception occured */
#endif
